package in.ineuron;
import java.util.*;
public class DSA_8Difference {
	
	 public static int smallestRangeI(int[] nums, int k) {
         Arrays.sort(nums);
        if(nums[0]+k >= nums[nums.length-1]-k)
            return 0;
        return nums[nums.length-1]-k-(nums[0]+k);
    }

	public static void main(String[] args) {
		int[] nums= {1,3,6};
		int k=3;
		int result=smallestRangeI(nums,k);
		System.out.println(result);

	}

}
