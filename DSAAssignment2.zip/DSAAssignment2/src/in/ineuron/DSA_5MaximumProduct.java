package in.ineuron;
import java.util.*;
public class DSA_5MaximumProduct {
	
	public static int  maximumProduct(int[] nums) {
        Arrays.sort(nums);
       int case1 = nums[0]*nums[1]*nums[nums.length-1];
       int case2 = nums[nums.length-1]*nums[nums.length-2]*nums[nums.length-3];

       int maxProduct = Math.max(case1, case2);
       return maxProduct;
   }
	

	public static void main(String[] args) {
		
		int nums[]= {1,2,3};
		int result=0;
		result=maximumProduct(nums);
		System.out.println(result);

	}

}
