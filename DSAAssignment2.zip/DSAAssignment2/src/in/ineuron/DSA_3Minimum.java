package in.ineuron;
import java.util.*;
public class DSA_3Minimum {
	
	    public static int findLHS(int[] nums) {
	        HashMap<Integer,Integer> map=new HashMap();
	        int res=0;
	        for(int a:nums)
	        {
	            map.put(a,map.getOrDefault(a,0)+1);  
	        }
	        for(int key:map.keySet())
	        {
	            if(map.containsKey(key+1))
	                res=Math.max(res,map.get(key)+map.get(key+1));
	        }
	        return res;
	    }

	public static void main(String[] args) {
		
		int number[] = {1,3,2,2,5,2,3,7};
		int result=0;
		result=findLHS(number);
		System.out.println(result);

	}

}
