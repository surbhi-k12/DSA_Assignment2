package in.ineuron;
import java.util.*;
public class DSA_2Candy {
	
	
	    public static int distributeCandies(int[] candyType) {
	        
	        Set<Integer> set = new HashSet<>();
	        for(int c : candyType)
	              set.add(c);
	        
	        return Math.min(candyType.length/2,set.size());

	        
	    }
	

	public static void main(String[] args) {
		
		int[] candy= {1,1,2,2,3,3};
		int result=0;
		result=distributeCandies(candy);
		System.out.println(result);

	}

}
