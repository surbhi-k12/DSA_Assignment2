package in.ineuron;
import java.util.*;
public class DSA_6Sort {
	 public static int search(int[] nums, int target) {
	  Arrays.sort(nums);
      int l,r,m;
      l=0;
      r=nums.length-1;
      while(l<=r){
          m=(l+r)/2;
          if(nums[m]==target)
          {
              return m;
          }
          if(nums[m]>target){
              r=m-1;
          }
          else{
              l=m+1;
          }
      }
          return -1;
	 }

	public static void main(String[] args) {
		int[] nums= {-1,0,3,5,9,12};
		int target=9;
		int result=search(nums,target);
		System.out.println(result);

	}

}
